import os
import json
import inspect
from pathlib import Path
from datetime import datetime
from pydantic import BaseModel
from functools import wraps, partial
from typing import Callable, Sequence, Union
from numbers import Number

# OpenTelemetry
from opentelemetry import trace as oteltrace
from opentelemetry.trace import ProxyTracer
from opentelemetry.sdk.trace import ReadableSpan
from opentelemetry.sdk.resources import Resource
from opentelemetry.sdk.trace import TracerProvider, Span
from opentelemetry.sdk.trace.export import (
    SpanExporter,
    SpanExportResult,
    SpanProcessor,
    BatchSpanProcessor,
)

_trace_name = "prompty"


def _check_tracer():
    if isinstance(oteltrace.get_tracer_provider().get_tracer(_trace_name), ProxyTracer):
        initialize_tracer()


def initialize_tracer(
    output_dir: str = None,
    span_exporters: Union[SpanExporter, Sequence[SpanExporter]] = None,
):
    resource = Resource.create({"service.name": _trace_name})
    provider = TracerProvider(resource=resource)

    exporters = []
    # if span processors are provided, use them
    if span_exporters:
        # if there's an explicit output directory,
        # use the prompty span processor also
        exporters = (
            list(span_exporters)
            if isinstance(span_exporters, Sequence)
            else [span_exporters]
        )
        if output_dir and not any(
            [e for e in exporters if isinstance(e, PromptySpanExporter)]
        ):
            exporters.append(PromptySpanExporter(output_dir))

    # otherwise, use the default prompty span processor
    elif output_dir:
        exporters.append(PromptySpanExporter(output_dir))
    else:
        exporters.append(PromptySpanExporter())

    for exporter in exporters:
        if isinstance(exporter, PromptySpanExporter):
            provider.add_span_processor(PromptySpanProcessor(exporter))
        else:
            provider.add_span_processor(BatchSpanProcessor(exporter))

    oteltrace.set_tracer_provider(provider)


def current_span() -> Span:
    _check_tracer()
    return oteltrace.get_current_span()


def current_tracer() -> oteltrace.Tracer:
    _check_tracer()
    return oteltrace.get_tracer(_trace_name)


class PromptySpanProcessor(SpanProcessor):
    def __init__(
        self, span_exporter: Union[SpanExporter, Sequence[SpanExporter]]
    ) -> None:
        super().__init__()
        self.span_exporters = (
            span_exporter if isinstance(span_exporter, Sequence) else [span_exporter]
        )
        self.spans = []

    def on_end(self, span: "Span") -> None:
        self.spans.append(span)
        # check for NOT PromptySpanExporters and trigger export
        for exporter in self.span_exporters:
            if not isinstance(exporter, PromptySpanExporter):
                exporter.export([span])

    def shutdown(self) -> None:
        for exporter in self.span_exporters:
            # if it's a PromptySpanExporter, export all the spans
            # otherwise they've already been exported
            if isinstance(exporter, PromptySpanExporter):
                exporter.export(self.spans)

    def force_flush(self, timeout_millis: int = 30000) -> bool:
        for exporter in self.span_exporters:
            exporter.export(self.spans)
            exporter.force_flush(timeout_millis)
        self.spans = []
        return True


class PromptySpanExporter(SpanExporter):
    output_dir: Path = None

    def __init__(self, output_dir: str = None):
        if output_dir:
            self.root = Path(output_dir).resolve().absolute()
        else:
            self.root = Path(Path(os.getcwd()) / ".runs").resolve().absolute()

        if not self.root.exists():
            self.root.mkdir(parents=True, exist_ok=True)

    def export(self, spans: Sequence[ReadableSpan]) -> SpanExportResult:
        s = [json.loads(span.to_json()) for span in spans]
        name = next(
            (obj for obj in s if not "parent_id" in obj or obj["parent_id"] == None),
            None,
        )
        if name:
            name = name["name"]
        else:
            name = "trace"

        trace_file = (
            self.root / f"{name}.{datetime.now().strftime('%Y%m%d.%H%M%S')}.ptrace"
        )
        with open(trace_file, "w") as f:
            json.dump(s, f, indent=2)
        return SpanExportResult.SUCCESS

    def force_flush(self, timeout_millis: int = 30000) -> bool:
        return True


def json_dump(obj):
    from .core import SimpleModel

    """
    Recursively converts a Python object to a JSON string.

    Args:
        obj: The Python object to be converted.

    Returns:
        A JSON string representation of the object.
    """

    if isinstance(obj, str):
        return obj
    elif isinstance(obj, datetime):
        return obj.isoformat()
    elif type(obj).__name__ == "Prompty":
        return obj.to_safe_json()
    elif isinstance(obj, SimpleModel):
        return json_dump(obj.item)
    elif isinstance(obj, Path):
        return str(obj)
    elif isinstance(obj, BaseModel):
        return obj.model_dump_json()
    elif isinstance(obj, list):
        return [json_dump(item) for item in obj]
    elif isinstance(obj, dict):
        return json.dumps(
            {k: v if isinstance(v, str) else json_dump(v) for k, v in obj.items()}
        )
    elif isinstance(obj, Number):
        return obj
    elif isinstance(obj, bool):
        return obj
    else:
        return str(obj)


def trace(func: Callable = None, *, description: str = None) -> Callable:
    """
    Decorator function that traces the execution of a given function.

    Args:
        func (Callable): The function to be traced.
        name (str, optional): The name of the output to be logged. Defaults to None.

    Returns:
        Callable: The wrapped function with tracing capabilities.
    """

    if func is None:
        return partial(trace, description=description)

    description = description or ""

    @wraps(func)
    def wrapper(*args, **kwargs):
        if hasattr(func, "__qualname__"):
            signature = f"{func.__module__}.{func.__qualname__}"
        else:
            signature = f"{func.__module__}.{func.__name__}"

        # core invoker gets special treatment
        core_invoker = signature == "prompty.core.Invoker.__call__"
        if core_invoker:
            span_name = type(args[0]).__name__
        else:
            span_name = func.__name__

        with current_tracer().start_as_current_span(span_name) as span:
            if core_invoker:
                span.set_attribute(
                    "signature",
                    f"{args[0].__module__}.{args[0].__class__.__name__}.invoke",
                )
            else:
                span.set_attribute("signature", signature)

            if len(description) > 0:
                span.set_attribute("description", description)

            ba = inspect.signature(func).bind(*args, **kwargs)
            ba.apply_defaults()
            if core_invoker:
                obj = args[1].model_dump()
                keys = list(obj.keys())
                if len(keys) == 1:
                    inputs = obj[keys[0]]
                else:
                    inputs = obj
            else:
                inputs = {
                    k: json_dump(v) for k, v in ba.arguments.items() if k != "self"
                }

            input = json_dump(inputs)
            span.set_attribute("input", input)
            result = func(*args, **kwargs)
            span.set_attribute(
                "result",
                json_dump(result) if result is not None else "None",
            )

        return result

    return wrapper
