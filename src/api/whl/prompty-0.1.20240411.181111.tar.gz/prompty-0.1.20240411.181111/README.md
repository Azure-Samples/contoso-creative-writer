# Prompty Reference Python Runtime
Prompty is an open source specification for a language model prompt template. This repository contains the reference implementation of the Prompty runtime in Python. The runtime is a Python package that can be used to execute Prompty templates and trace the execution of the templates. The runtime is designed to be used in a variety of contexts including local development, cloud services, and edge devices.


## Template Specification
The Prompty template language is is based on [Jinja](https://jinja.palletsprojects.com/en/3.0.x/) (for TS/JS [Nunjucks](https://mozilla.github.io/nunjucks/)) and supports the following features:

1. **Variables** ([Jinja2](https://jinja.palletsprojects.com/en/3.0.x/templates/#variables) / [Nunjucks](https://mozilla.github.io/nunjucks/templating.html#variables)) - the ability to reference variables
2. **Filters** ([Jinja2](https://jinja.palletsprojects.com/en/3.0.x/templates/#filters) / [Nunjucks](https://mozilla.github.io/nunjucks/templating.html#filters)) - the ability to apply filters to variables
3. **Control structures** - the ability to use control structures like `for` loops ([Jinja2](https://jinja.palletsprojects.com/en/3.0.x/templates/#loop-controls) / [Nunjucks](https://mozilla.github.io/nunjucks/templating.html#for)) and conditionals ([Jinja2](https://jinja.palletsprojects.com/en/3.0.x/templates/#if) / [Nunjucks](https://mozilla.github.io/nunjucks/templating.html#if))
4. **Template inheritance** ([Jinja2](https://jinja.palletsprojects.com/en/3.0.x/templates/#base-template) / [Nunjucks](https://mozilla.github.io/nunjucks/templating.html#template-inheritance)) - the ability to define and use template inheritance

## Prompty Specification
The prompty asset is a markdown file with a modified front matter. The front matter is in yaml format that contains a number of fields. These are most relevant ones:

| Field | Description |
| --- | --- |
| name | The name of the prompt |
| api | The LLM API type to use (chat or completion) -- this will also determine how the template output is processed into the LLM request. |
| model | The model to use -- here the model type and connection information is provided. |
| parameters | A list of parameters sent to the LLM API |
| inputs | A list of inputs -- these can be inline in the yaml frontmatter or in a seperate file to which this property points |
| template | The template language to use (Nunjucks, jinja2, f-string). The current default is jinja2 |
| description | A description of the prompt |
| authors | A list of authors |
| base | The base prompty file to use -- this is used to create a prompty that extends another prompty. |

A more detailed schema format can be found in the [Prompty.yaml](Prompty.yaml) file. The following is an example of a prompty template:

```jinja
---
name: Basic Prompt
description: A basic prompt that uses the GPT-3 chat API to answer questions
authors:
  - sethjuarez
  - jietong
api: chat
model:
  azure_deployment: gpt-35-turbo
inputs:
  firstName: Jane
  lastName: Doe
  question: What is the meaning of life?
---
system:
You are an AI assistant who helps people find information.
As the assistant, you answer questions briefly, succinctly, 
and in a personable manner using markdown and even add some personal flair with appropriate emojis.

# Customer
You are helping {{firstName}} {{lastName}} to find answers to their questions.
Use their name to address them in your responses.

user:
{{question}}
```

## Runtime Specification
The runtime includes three main features:
- load
- execute
- trace

### load
the ability to load a template from a given path

```python
from prompty import load
# override some parameters during load
my_prompty = load(prompt="basic.prompty", 
                  parameters={"temperature": 0.5}, 
                  model={"azure_deployment": "gpt-35-turbo-2"})
```


### execute 
the ability to execute a template with a given context (both synchronously as well as asyncrhonously)

```python
from prompty import load, execute

# without default input values
result = execute("basic.prompty")

# with input values
result = execute("basic.prompty", inputs={ 
  "firstName": "Seth", 
  "lastName": "Juarez",
  "question": "What is the meaning of life?"
})

# or preloaded
my_prompty = load(prompt="basic.prompty", 
                  parameters={"temperature": 0.5}, 
                  model={"azure_deployment": "gpt-35-turbo-2"})
result = execute(my_prompty)
```

### trace
The ability to trace a an LLM prompty flow (see what I did there?) with a given context. The output should be rendered in a format that can be used by OpenTelemetry (preferably using their APIs).

```python
from prompty import trace, execute

@trace
def get_customer(customerId):
    # we would look this up in a database
    return {"id": customerId, "firstName": "Sally", "lastName": "Davis"}


@trace(description="basic context used to grounded the response")
def get_context(search):
    # we would be using a search engine here
    return [
        {
            "id": "17",
            "name": "RainGuard Hiking Jacket",
            "price": 110,
            "category": "Hiking Clothing",
            "brand": "MountainStyle",
            "description": "Introducing the MountainStyle RainGuard Hiking Jacket",
        },
    ]

@trace
def get_response(customerId, question):
    customer = get_customer(customerId)
    context = get_context(question)
    prompt = "./myprompts/rag.prompty"
    result = execute(
        prompt,
        inputs={"question": question, "customer": customer, "documentation": context},
    )
    return {"question": question, "answer": result, "context": context}

if __name__ == "__main__":
    get_response(argv[1], argv[2])
```

In a pure local mode, this creates OTel tracing in a local run file. Notice also that the `trace` decorator can be used to trace the entire execution flow that leads to an LLM call. The runtime handles this as well and produces a trace that can be used by OpenTelemetry.


# Prompty Runtime Object Model
[ Need to rewrite with latest changes ]



The prompty runtime object model is a set of classes that represent the Prompty template and its execution. It is designed to be extensible and can be used to create custom runtime implementations or even extend the existing runtime.

![prompty runtime](execution.png "Prompty Execution Steps")

The runtime uses a 5 step execute a template:

1. **Load** the prompty template
2. **Render** the template to produce a prompt
3. **Parse** the rendered text to fit the model
4. **Execute** the prompt against the model
5. **Process** the response

## Tracer
The tracer is responsible for tracing the execution of the template. The runtime supports tracing the execution of the template using OpenTelemetry. There is a `@trace` decorator that can be used to trace the execution of a function. 

The trace implementation can be found [here](prompty/tracer.py).


# Contributing

This project welcomes contributions and suggestions.  Most contributions require you to agree to a
Contributor License Agreement (CLA) declaring that you have the right to, and actually do, grant us
the rights to use your contribution. For details, visit https://cla.opensource.microsoft.com.

When you submit a pull request, a CLA bot will automatically determine whether you need to provide
a CLA and decorate the PR appropriately (e.g., status check, comment). Simply follow the instructions
provided by the bot. You will only need to do this once across all repos using our CLA.

This project has adopted the [Microsoft Open Source Code of Conduct](https://opensource.microsoft.com/codeofconduct/).
For more information see the [Code of Conduct FAQ](https://opensource.microsoft.com/codeofconduct/faq/) or
contact [opencode@microsoft.com](mailto:opencode@microsoft.com) with any additional questions or comments.

# Trademarks

This project may contain trademarks or logos for projects, products, or services. Authorized use of Microsoft 
trademarks or logos is subject to and must follow 
[Microsoft's Trademark & Brand Guidelines](https://www.microsoft.com/en-us/legal/intellectualproperty/trademarks/usage/general).
Use of Microsoft trademarks or logos in modified versions of this project must not cause confusion or imply Microsoft sponsorship.
Any use of third-party trademarks or logos are subject to those third-party's policies.
